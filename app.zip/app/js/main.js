$(document).ready(function(){
	console.log('I am on the global page');
});